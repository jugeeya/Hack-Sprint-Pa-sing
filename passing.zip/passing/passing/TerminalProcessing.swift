
import Foundation

func process (toProcess:String) -> String{
    
    
    return toProcess.uppercased()
    
}
